from flask import Flask, render_template, flash, url_for, redirect
from forms import *
from models import *
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_bootstrap import Bootstrap
from app import app, db
from flask import Flask, render_template, request, flash, redirect, url_for, session
from forms import Forms


app.secret_key = '31498657699432922335'
app.debug = True
bootstrap = Bootstrap(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    return Users.query.get(user_id)


@app.route('/')
def index():
    if current_user.is_authenticated is True:
        return redirect(url_for('home'))
    return render_template('index.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = RegistrationForm()
    if current_user.is_authenticated is True:
        return redirect(url_for('home'))
    elif form.validate_on_submit():
        hashed = generate_password_hash(form.password.data, method='sha256')
        new_user = Users(form.username.data, hashed, form.first_name.data,
                         form.last_name.data, form.middle_initial.data, form.contact.data, form.sex.data,
                         form.year.data+'-'+form.month.data+'-'+form.day.data)
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user, remember=True)
        return redirect(url_for('home'))
    return render_template('registration.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if current_user.is_authenticated is True:
        return redirect(url_for('home'))
    elif form.validate_on_submit():
        user = Users.query.filter_by(username=form.username.data).first()
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember=True)
                return redirect(url_for('home'))
            else:
                flash('Invalid username or password')
                return render_template('login.html', form=form)
        else:
            return render_template('login.html', form=form)
    return render_template('login.html', form=form)


@app.route('/home')
@login_required
def home():
    return render_template('dashboard.html', name=current_user)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route('/profile/<int:page_num>', methods=['GET', 'POST'])
@login_required
def profile(page_num):
    pags = Shelf.query.paginate(per_page= 3, page=page_num, error_out=True)
    form = EditProfile()
    if form.validate_on_submit():
        update = Users.query.filter_by(id=current_user.id).first()
        update.first_name = form.first_name.data
        update.last_name = form.last_name.data
        update.middle_initial = form.middle_initial.data
        update.contact_number = form.contact.data
        db.session.commit()
        return redirect(url_for('home'))

    elif request.method == 'POST':
        ratingNew = int(request.form['rate'])
        bookidNew = request.form['Store']
        if ratingNew > 0:
            userRate = Shelf.query.filter_by(bookid=bookidNew).first()
            rate = userRate.rating
            raters = userRate.raters

            dividend = ratingNew+rate
            ratersTot = raters+1

            total = float(dividend/ratersTot)

            userRate.rating = total
            userRate.raters = ratersTot
            db.session.commit()

            pags = Shelf.query.paginate(per_page=20, page=page_num, error_out=True)
        else:
            pass
        form = EditProfile()
        return render_template('profile.html', pags = pags, data=current_user,form = form)


    return render_template('profile.html', data=current_user, form=form, pags = pags)


@app.route('/adder', methods = ['POST', 'GET'])
@login_required
def adder():
    form = Forms(request.form)
    if request.method == 'POST':
        titleNew = form.titleNew.data
        yearNew = form.yearNew.data
        typeNew = form.typeNew.data
        authorNew = form.authorNew.data
        editionNew = form.editionNew.data
        isbnNew = form.isbnNew.data

        if form.validate():
            book = Shelf(titleNew,yearNew,typeNew,authorNew,editionNew,isbnNew,0,0)
            db.session.add(book)
            db.session.commit()
            flash('Book successfully added', 'success')
            return redirect(url_for('profile', page_num=1))

        elif not form.validate():
            flash("Please don't leave any blank", 'error')
            return render_template("add.html", form=form)
        else:
            return render_template("add.html", form=form)


    else:
        return render_template("add.html", form=form)

@app.route('/delete', methods = ['POST', 'GET'])
@login_required
def deletefunc():
    deleteStore = request.form['Store']
    if request.method == 'POST':
        Shelf.query.filter_by(bookid=deleteStore).delete()
        db.session.commit()
        return redirect(url_for('profile', page_num=1))

    else:
        return redirect(url_for('profile'))

@app.route('/updateBook', methods = ['POST', 'GET'])
@login_required
def updateGet():
    updateStore = request.form['Store']

    if request.method == 'POST':
        session['bookidNew'] = updateStore
        return redirect(url_for('update'))

    else:
        return redirect(url_for('profile', page_num=1))


@app.route('/updateForm', methods = ['POST', 'GET'])
@login_required
def update():

    form = Forms(request.form)
    bookidNew = session['bookidNew']
    if request.method == 'POST':
        titleNew = form.titleNew.data
        yearNew = form.yearNew.data
        typeNew = form.typeNew.data
        authorNew = form.authorNew.data
        editionNew = form.editionNew.data
        isbnNew = form.isbnNew.data


        if form.validate():
            updateNew = Shelf.query.filter_by(bookid = bookidNew).first()

            updateNew.title = titleNew
            updateNew.year = yearNew
            updateNew.type = typeNew
            updateNew.author = authorNew
            updateNew.edition = editionNew
            updateNew.isbn = isbnNew
            db.session.commit()

            return redirect(url_for('profile', page_num=1))

        elif not form.validate():
            flash('Please fill up each of the following', 'error')
            return render_template("update.html", form = form)

        else:
            return render_template("update.html", form = form)


    else:
        return render_template("update.html", form=form)

@app.route('/searchGet/<int:page_num>', methods = ['POST', 'GET'])
@login_required
def searchGet(page_num):
    form = EditProfile()
    search = request.form['search']
    if request.method == 'POST':

        search1 = "%"+search+"%"
        pags = Shelf.query.filter((Shelf.title.like(search1)) | (Shelf.year.like(search1)) | (Shelf.type.like(search1)) | (Shelf.author.like(search1)) | (Shelf.edition.like(search1)) | (Shelf.isbn.like(search1)) | (Shelf.rating.like(search1))).paginate(page_num,10)



        return render_template('profile.html', pags = pags, data=current_user,form = form)

    else:
        return render_template('profile.html', pags = pags, data=current_user,form = form)
